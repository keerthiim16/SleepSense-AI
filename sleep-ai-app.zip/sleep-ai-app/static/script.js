const chatArea = document.getElementById("chatArea");
const sendBtn = document.getElementById("sendBtn");
const resultPanel = document.getElementById("resultPanel");
const historyList = document.getElementById("historyList");

// Calculator page elements (restore original pre-modified behavior)
const wakeTimeInput = document.getElementById("wakeTime");
const fallAsleepMinsInput = document.getElementById("fallAsleepMins");
const calculateSleepBtn = document.getElementById("calculateSleepBtn");
const calcResult = document.getElementById("calcResult");

const btnBaseline = document.getElementById("btnBaseline");
const btnIncreaseSleep = document.getElementById("btnIncreaseSleep");
const btnReduceStress = document.getElementById("btnReduceStress");
const btnIncreaseActivity = document.getElementById("btnIncreaseActivity");

let predictionBundle = null;

function addBubble(text, role) {
    if (!chatArea) return;
    const div = document.createElement("div");
    div.className = `bubble ${role}`;
    div.textContent = text;
    chatArea.appendChild(div);
    chatArea.scrollTop = chatArea.scrollHeight;
}

function setError(id, message) {
    const el = document.getElementById(id);
    if (!el) return;
    if (!message) {
        el.innerText = "";
        el.classList.remove("visible");
    } else {
        el.innerText = message;
        el.classList.add("visible");
    }
}

function validateAge() {
    const age = Number(document.getElementById("age")?.value);
    setError("ageError", "");
    if (!age) return setError("ageError", "Age is required"), false;
    if (age < 10 || age > 100) return setError("ageError", "Age must be between 10 and 100"), false;
    return true;
}

function validateRequiredSelect(id, errorId, label) {
    const value = document.getElementById(id)?.value || "";
    setError(errorId, "");
    if (!value) return setError(errorId, `${label} is required`), false;
    return true;
}

function validateRange(id, errorId, label, min, max) {
    const value = Number(document.getElementById(id)?.value);
    setError(errorId, "");
    if (!value && value !== 0) return setError(errorId, `${label} is required`), false;
    if (value < min || value > max) return setError(errorId, `${label} must be between ${min} and ${max}`), false;
    return true;
}

function validateBloodPressure() {
    const value = document.getElementById("bloodPressure")?.value.trim() || "";
    setError("bloodPressureError", "");
    if (!value) return setError("bloodPressureError", "Blood Pressure is required"), false;
    if (!/^\d{2,3}\/\d{2,3}$/.test(value)) {
        return setError("bloodPressureError", "Blood Pressure must be in format 120/80"), false;
    }
    return true;
}

function gatherFormData() {
    return {
        Gender: document.getElementById("gender")?.value || "",
        Age: document.getElementById("age")?.value || "",
        Occupation: document.getElementById("occupation")?.value || "",
        "Sleep Duration": document.getElementById("sleepDuration")?.value || "",
        "Physical Activity Level": document.getElementById("activity")?.value || "",
        "Stress Level": document.getElementById("stress")?.value || "",
        "BMI Category": document.getElementById("bmi")?.value || "",
        "Heart Rate": document.getElementById("heartRate")?.value || "",
        "Daily Steps": document.getElementById("dailySteps")?.value || "",
        "Blood Pressure": document.getElementById("bloodPressure")?.value || "",
    };
}

function validateDashboardForm() {
    const checks = [
        validateRequiredSelect("gender", "genderError", "Gender"),
        validateAge(),
        validateRequiredSelect("occupation", "occupationError", "Occupation"),
        validateRange("sleepDuration", "sleepDurationError", "Sleep Duration", 2, 14),
        validateRange("activity", "activityError", "Physical Activity Level", 0, 100),
        validateRange("stress", "stressError", "Stress Level", 1, 10),
        validateRequiredSelect("bmi", "bmiError", "BMI Category"),
        validateRange("heartRate", "heartRateError", "Heart Rate", 30, 180),
        validateRange("dailySteps", "dailyStepsError", "Daily Steps", 500, 50000),
        validateBloodPressure(),
    ];
    return checks.every(Boolean);
}

function riskClass(level) {
    const val = (level || "").toLowerCase();
    if (val === "low") return "risk-low";
    if (val === "high") return "risk-high";
    return "risk-medium";
}

function renderResults(payload, label = "Baseline") {
    if (!resultPanel) return;
    resultPanel.innerHTML = `
        <div class="result-item"><h3>Scenario</h3><p>${label}</p></div>
        <div class="result-item"><h3>Sleep Disorder</h3><p>${payload.sleep_disorder}</p></div>
        <div class="result-item"><h3>Sleep Score</h3><p>${payload.sleep_score}/100</p></div>
        <div class="result-item"><h3>Risk Level</h3><p class="${riskClass(payload.risk_level)}">${payload.risk_level}</p></div>
        <div class="result-item span-2"><h3>Sleep Persona</h3><p>${payload.persona}</p></div>
        <div class="result-item span-2"><h3>AI Explanation</h3><p>${payload.explanations.join(" ")}</p></div>
        <div class="result-item span-2"><h3>📊 Your Behavior vs Dataset</h3>
            <div class="behavior-list">
                <div class="behavior-item">Stress Level: ${payload.behavior_insights.stress_comparison} ${payload.behavior_insights.stress_comparison === 'Higher than average' ? '⚠️' : '✅'}</div>
                <div class="behavior-item">Sleep Duration: ${payload.behavior_insights.sleep_comparison} ${payload.behavior_insights.sleep_comparison === 'Lower than average' ? '⚠️' : '✅'}</div>
                <div class="behavior-item">Activity Level: ${payload.behavior_insights.activity_comparison} ${payload.behavior_insights.activity_comparison === 'Below average' ? '⚠️' : '✅'}</div>
            </div>
        </div>
        <div class="result-item span-2"><h3>🧠 AI Explanation</h3><p>${payload.ai_explanation}</p></div>
        <div class="result-item span-2"><h3>💡 OpenAI Suggestions</h3>
            <ul style="margin: 0 0 8px 16px; padding-left: 0;">
                ${(payload.openai_suggestions || []).map(item => `<li style="margin: 4px 0;">${item}</li>`).join('')}
            </ul>
        </div>
        <div class="result-item span-2"><h3>📊 OpenAI Insight</h3><p>${payload.openai_insight || 'No insight available at this time.'}</p></div>
        <div class="result-item span-2"><h3>📈 Weekly Sleep Score Trend</h3>
            <div class="trend-graph" id="trendGraph">
                ${[60, 65, 72, 68, 75, 80, payload.sleep_score || 70].map((val, idx) => `
                    <div class="trend-bar" style="height:${Math.min(95, Math.max(20,val))}%" title="Day ${idx + 1}: ${val}/100">
                        <span>${val}</span>
                    </div>
                `).join('')}
            </div>
        </div>
        <div class="result-item span-2"><h3>�💼 Personalized Recommendations</h3>
            <ul class="recommendations-list">
                ${payload.occupation_recommendations.map(rec => `<li>${rec}</li>`).join('')}
            </ul>
        </div>
        <div class="result-item span-2"><h3>💡 Expert Sleep Tips</h3>
            <div class="tips-grid">
                ${payload.expert_tips.slice(0, 6).map(tip => `<div class="tip-item">${tip}</div>`).join('')}
            </div>
        </div>
    `;
}

function setScenarioButtonState(target) {
    [btnBaseline, btnIncreaseSleep, btnReduceStress, btnIncreaseActivity]
        .filter(Boolean)
        .forEach((btn) => btn.classList.remove("active"));
    target.classList.add("active");
}

function humanizeTime(ts) {
    const created = new Date(ts.replace(" ", "T"));
    const now = new Date();
    const diffDays = Math.floor((now - created) / (1000 * 60 * 60 * 24));
    if (diffDays === 0) return `Today at ${created.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    if (diffDays === 1) return `Yesterday at ${created.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    if (diffDays < 7) return `${diffDays} days ago`;
    return created.toLocaleDateString([], { month: "short", day: "numeric" });
}

async function loadHistory() {
    if (!historyList) return;
    const res = await fetch("/history");
    if (!res.ok) return;
    const data = await res.json();
    if (!data.history || data.history.length === 0) {
        historyList.innerHTML = "<li>No history yet.</li>";
        return;
    }
    historyList.innerHTML = data.history
        .map((item) => {
            let inputStr = "Inputs: ";
            try {
                const inputObj = JSON.parse(item.input_data.replace(/'/g, '\"'));
                inputStr += `Stress:${inputObj["Stress Level"]||'?'} Sleep:${inputObj["Sleep Duration"]||'?'}h Activity:${inputObj["Physical Activity Level"]||'?'}%`;
            } catch (e) {
                inputStr += item.input_data.substring(0, 40) + "...";
            }
            return `<li><strong>${item.result}</strong><br/>${inputStr}<br/><small>${item.formatted_time}</small></li>`;
        })
        .join("");
}

async function submitPrediction() {
    const formData = gatherFormData();
    if (!validateDashboardForm()) return;

    const statusLine = document.getElementById('analysisStatus');
    if (statusLine) {
        statusLine.textContent = 'Analyzing your sleep profile...';
        statusLine.style.color = '#aad4ff';
    }

    const sendBtnElement = document.getElementById('sendBtn');
    if (sendBtnElement) {
        sendBtnElement.disabled = true;
        sendBtnElement.textContent = 'Analyzing...';
    }

    try {
        const response = await fetch("/predict", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData),
        });
        const data = await response.json();
        if (!response.ok) {
            addBubble(data.error || "Prediction failed. Please try again.", "bot");
            if (statusLine) statusLine.textContent = 'Prediction failed. Check your inputs and try again.';
            return;
        }

        predictionBundle = data;
        renderResults(data, "Baseline");
        addBubble(`Your profile indicates: ${data.sleep_disorder} with ${data.risk_level} risk.`, "bot");
        if (statusLine) statusLine.textContent = 'Analysis complete!';
        loadHistory();
    } catch (error) {
        addBubble('Prediction failed. Please try again.', 'bot');
        if (statusLine) statusLine.textContent = 'Network error; retry after checking connection.';
    } finally {
        if (sendBtnElement) {
            sendBtnElement.disabled = false;
            sendBtnElement.textContent = 'Analyze Sleep';
        }
    }
}

if (sendBtn) {
    sendBtn.addEventListener("click", () => {
        if (!validateDashboardForm()) return;
        submitPrediction();
    });
}

if (btnBaseline) {
    btnBaseline.addEventListener("click", () => {
        if (!predictionBundle) return;
        setScenarioButtonState(btnBaseline);
        renderResults(predictionBundle, "Baseline");
    });
}

if (btnIncreaseSleep) {
    btnIncreaseSleep.addEventListener("click", () => {
        if (!predictionBundle) return;
        setScenarioButtonState(btnIncreaseSleep);
        renderResults(predictionBundle.scenarios.increase_sleep, "Increase Sleep");
    });
}

if (btnReduceStress) {
    btnReduceStress.addEventListener("click", () => {
        if (!predictionBundle) return;
        setScenarioButtonState(btnReduceStress);
        renderResults(predictionBundle.scenarios.reduce_stress, "Reduce Stress");
    });
}

if (btnIncreaseActivity) {
    btnIncreaseActivity.addEventListener("click", () => {
        if (!predictionBundle) return;
        setScenarioButtonState(btnIncreaseActivity);
        renderResults(predictionBundle.scenarios.increase_activity, "Increase Activity");
    });
}

const clearHistoryBtn = document.getElementById("clearHistoryBtn");

if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener("click", async () => {
        if (confirm("Are you sure you want to clear all your prediction history?")) {
            const response = await fetch("/clear_history", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
            });
            const data = await response.json();
            if (response.ok && data.success) {
                loadHistory(); // Reload history
                alert("History cleared successfully!");
            } else {
                alert("Failed to clear history: " + (data.error || "Unknown error"));
            }
        }
    });
}

function minutesFromTime(timeStr) {
    const [h, m] = timeStr.split(":").map(Number);
    return h * 60 + m;
}

function formatTo12Hour(totalMinutes) {
    const wrapped = ((totalMinutes % 1440) + 1440) % 1440;
    const h24 = Math.floor(wrapped / 60);
    const mins = wrapped % 60;
    const suffix = h24 >= 12 ? "PM" : "AM";
    const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
    return `${h12}:${String(mins).padStart(2, "0")} ${suffix}`;
}

function runSleepCalculator() {
    if (!wakeTimeInput || !fallAsleepMinsInput || !calcResult) return;

    const wakeTime = wakeTimeInput.value || "07:00";
    const fallAsleepMins = Number(fallAsleepMinsInput.value);

    if (!wakeTime || Number.isNaN(fallAsleepMins) || fallAsleepMins < 5) {
        calcResult.innerHTML = '<div class="placeholder">Please enter a valid wake-up time and fall-asleep duration (5+ minutes).</div>';
        return;
    }

    const [hour, minute] = wakeTime.split(":").map(Number);
    const wakeMins = hour * 60 + minute;

    // Compute recommended times for 4-6 sleep cycles (90-minute cycle each)
    const base = wakeMins - fallAsleepMins - 90;
    const times = [base - 270, base - 180, base - 90, base];

    calcResult.innerHTML = times
        .map((t) => {
            const wrapped = ((t % 1440) + 1440) % 1440;
            const h = Math.floor(wrapped / 60).toString().padStart(2, "0");
            const m = Math.floor(wrapped % 60).toString().padStart(2, "0");
            return `<div class="result-item"><h3>Best Bedtime</h3><p>${h}:${m}</p></div>`;
        })
        .join("");
}

if (calculateSleepBtn) {
    calculateSleepBtn.addEventListener("click", runSleepCalculator);
    runSleepCalculator();
}

function toggleFaq(index) {
    const answer = document.getElementById(`faq-${index}`);
    const toggle = answer.previousElementSibling.querySelector('.faq-toggle');
    if (answer.style.display === 'block') {
        answer.style.display = 'none';
        toggle.textContent = '▼';
    } else {
        answer.style.display = 'block';
        toggle.textContent = '▲';
    }
}

function searchFaq() {
    const searchInput = document.getElementById('faqSearch');
    const filter = searchInput.value.toLowerCase();
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const keywords = item.getAttribute('data-keywords');
        if (keywords.includes(filter)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Sleep Tracking Functionality
const startSleepLogBtn = document.getElementById('startSleepLogBtn');
const stopSleepLogBtn = document.getElementById('stopSleepLogBtn');
const sleepLogStatus = document.getElementById('sleepLogStatus');
const sleepLogResults = document.getElementById('sleepLogResults');

let sleepLogStartTime = null;
let sleepLogInterval = null;

if (startSleepLogBtn) {
    startSleepLogBtn.addEventListener('click', () => {
        sleepLogStartTime = new Date();
        
        // Update UI
        startSleepLogBtn.style.display = 'none';
        stopSleepLogBtn.style.display = 'inline-block';
        sleepLogStatus.style.display = 'flex';
        sleepLogResults.style.display = 'none';
        
        // Start real-time logging (simulate logging to laptop)
        sleepLogInterval = setInterval(() => {
            // This would normally log to a file/database
            console.log(`Sleep logging active: ${new Date().toLocaleTimeString()}`);
        }, 60000); // Log every minute
        
        // Show notification
        showSleepNotification('Sleep logging started! Go to bed now.');
    });
}

if (stopSleepLogBtn) {
    stopSleepLogBtn.addEventListener('click', () => {
        if (!sleepLogStartTime) return;
        
        const endTime = new Date();
        const duration = endTime - sleepLogStartTime;
        
        // Calculate sleep metrics
        const bedtime = sleepLogStartTime.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
        const waketime = endTime.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
        const hours = Math.floor(duration / (1000 * 60 * 60));
        const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
        const durationStr = `${hours}h ${minutes}m`;
        
        // Calculate quality score (simplified algorithm)
        const qualityScore = calculateSleepQuality(duration, sleepLogStartTime, endTime);
        
        // Update UI
        document.getElementById('bedtimeDisplay').textContent = bedtime;
        document.getElementById('waketimeDisplay').textContent = waketime;
        document.getElementById('durationDisplay').textContent = durationStr;
        document.getElementById('qualityDisplay').textContent = `${qualityScore}/10`;
        
        // Reset UI
        startSleepLogBtn.style.display = 'inline-block';
        stopSleepLogBtn.style.display = 'none';
        sleepLogStatus.style.display = 'none';
        sleepLogResults.style.display = 'block';
        
        // Stop logging interval
        if (sleepLogInterval) {
            clearInterval(sleepLogInterval);
            sleepLogInterval = null;
        }
        
        // Save to local file (simulate saving to laptop)
        saveSleepLogToFile({
            date: new Date().toISOString().split('T')[0],
            bedtime: bedtime,
            waketime: waketime,
            duration: durationStr,
            quality: qualityScore,
            timestamp: new Date().toISOString()
        });
        
        // Show notification
        showSleepNotification(`Sleep logged! Quality: ${qualityScore}/10`);
        
        sleepLogStartTime = null;
    });
}

function calculateSleepQuality(durationMs, startTime, endTime) {
    const hours = durationMs / (1000 * 60 * 60);
    
    // Base score on duration (7-9 hours = 10, less = lower)
    let score = Math.min(10, Math.max(1, hours * 1.25));
    
    // Adjust for bedtime (optimal: 10 PM - 12 AM)
    const bedHour = startTime.getHours();
    if (bedHour >= 22 || bedHour <= 2) {
        score += 0.5; // Good bedtime
    } else if (bedHour >= 3 && bedHour <= 6) {
        score -= 1; // Late bedtime
    }
    
    // Adjust for wake time (optimal: 6 AM - 8 AM)
    const wakeHour = endTime.getHours();
    if (wakeHour >= 6 && wakeHour <= 8) {
        score += 0.5; // Good wake time
    } else if (wakeHour >= 9) {
        score -= 1; // Late wake time
    }
    
    return Math.round(Math.max(1, Math.min(10, score)));
}

function saveSleepLogToFile(logData) {
    // Create log entry
    const logEntry = {
        ...logData,
        logged_at: new Date().toISOString()
    };
    
    // In a real app, this would save to a database or file
    // For now, we'll save to localStorage and also log to console
    const existingLogs = JSON.parse(localStorage.getItem('sleepLogs') || '[]');
    existingLogs.push(logEntry);
    localStorage.setItem('sleepLogs', JSON.stringify(existingLogs));
    
    // Also save to a text file (simulate saving to laptop)
    const logText = `Sleep Log - ${logEntry.date}\n` +
                   `Bedtime: ${logEntry.bedtime}\n` +
                   `Wake Time: ${logEntry.waketime}\n` +
                   `Duration: ${logEntry.duration}\n` +
                   `Quality Score: ${logEntry.quality}/10\n` +
                   `Logged at: ${logEntry.logged_at}\n` +
                   `---\n`;
    
    console.log('Sleep log saved to laptop:', logText);
    
    // In a real implementation, you could use the File System API or send to server
    // For demo purposes, we'll create a downloadable file
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sleep-log-${logEntry.date}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

/* ===== RESIZABLE PANELS ===== */
function initPanelResizing() {
    const divider = document.querySelector('.divider');
    const sidebar = document.querySelector('.left-panel');
    const mainArea = document.querySelector('.right-panel');
    const container = document.querySelector('.resizable-container');

    if (!divider || !sidebar || !mainArea || !container) return;
    
    let isResizing = false;
    let startX = 0;
    let startLeftWidth = 0;

    function startResize(e) {
        e.preventDefault();
        isResizing = true;
        startX = e.clientX;
        startLeftWidth = sidebar.offsetWidth;
        document.body.style.cursor = 'ew-resize';
        document.body.style.userSelect = 'none';
    }
    
    function doResize(e) {
        if (!isResizing) return;

        const deltaX = e.clientX - startX;
        const minWidth = 260;
        const maxWidth = container.offsetWidth - 260;
        const newSidebarWidth = Math.max(minWidth, Math.min(maxWidth, startLeftWidth + deltaX));

        sidebar.style.width = newSidebarWidth + 'px';
        sidebar.style.minWidth = newSidebarWidth + 'px';
        sidebar.style.maxWidth = newSidebarWidth + 'px';
    }

    function endResize() {
        isResizing = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
    }

    // Divider events
    divider.addEventListener('mousedown', startResize);

    // Keep mousemove on document while resizing
    document.addEventListener('mousemove', doResize);
    document.addEventListener('mouseup', endResize);
}

// Initialize panel resizing on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        initPanelResizing();
    });
} else {
    initPanelResizing();
}

function showSleepNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'sleep-notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--accent);
        color: #001a2c;
        padding: 12px 20px;
        border-radius: 10px;
        font-weight: 700;
        box-shadow: 0 4px 12px rgba(56, 189, 248, 0.3);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

if (chatArea) {
    addBubble("Welcome to SleepSense AI. Fill your details below and click Analyze Sleep.", "bot");
    loadHistory();
}
